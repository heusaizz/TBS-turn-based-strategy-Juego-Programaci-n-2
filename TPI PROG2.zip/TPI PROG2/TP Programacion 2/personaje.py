import random

class Personaje:
    _id_counter = 1

    def __init__(self, nombre, fuerza, inteligencia, defensa, vida):
        self.id = Personaje._id_counter
        Personaje._id_counter += 1
        self.nombre = nombre
        self.fuerza = fuerza
        self.inteligencia = inteligencia
        self.defensa = defensa
        self.vida = vida

    def atributos(self):
        print(f"{self.nombre} (ID: {self.id}):")
        print(f"·Fuerza: {self.fuerza}")
        print(f"·Inteligencia: {self.inteligencia}")
        print(f"·Defensa: {self.defensa}")
        print(f"·Vida: {self.vida}")

    def subir_nivel(self, fuerza, inteligencia, defensa):
        self.fuerza += fuerza
        self.inteligencia += inteligencia
        self.defensa += defensa

    def esta_vivo(self):
        return self.vida > 0

    def morir(self):
        self.vida = 0
        print(f"{self.nombre} ha muerto")

    def daño(self, enemigo):
        return self.fuerza - enemigo.defensa

    def atacar(self, enemigo):
        daño = self.daño(enemigo)
        enemigo.vida -= daño
        print(f"{self.nombre} ha realizado {daño} puntos de daño a {enemigo.nombre}")
        if enemigo.esta_vivo():
            print(f"Vida de {enemigo.nombre} es {enemigo.vida}")
        else:
            enemigo.morir()

    def menu_ataque(self, enemigo):
        while True:
            print("\nSelecciona una acción:")
            print("1. Ataque fuerte")
            print("2. Ataque rápido")
            print("3. Pócima regeneradora")
            opcion = input("Elige una opción (1/2/3): ")
            if opcion == '1':
                self.ataque_fuerte(enemigo)
                break
            elif opcion == '2':
                self.ataque_rapido(enemigo)
                break
            elif opcion == '3':
                self.pocima_regeneradora()
                break
            else:
                print("Opción no válida, intenta de nuevo.")

    def ataque_fuerte(self, enemigo):
        raise NotImplementedError("Debe implementar este método en la subclase")

    def ataque_rapido(self, enemigo):
        raise NotImplementedError("Debe implementar este método en la subclase")

    def pocima_regeneradora(self):
        self.vida += 11
        print(f"{self.nombre} ha usado una Pócima regeneradora y recuperado 11 puntos de vida. Vida actual: {self.vida}")

class Guerrero(Personaje):
    def __init__(self, nombre, fuerza, inteligencia, defensa, vida, espada):
        super().__init__(nombre, fuerza, inteligencia, defensa, vida)
        self.espada = espada

    def cambiar_arma(self):
        while True:
            try:
                opcion = int(input("Elige un arma: (1) Acero Valyrio, daño 8. (2) Matadragones, daño 10: "))
                if opcion == 1:
                    self.espada = 8
                    break
                elif opcion == 2:
                    self.espada = 10
                    break
                else:
                    print("Número de arma incorrecta")
            except ValueError:
                print("Entrada inválida. Por favor ingrese un número.")

    def atributos(self):
        super().atributos()
        print(f"·Espada: {self.espada}")

    def ataque_fuerte(self, enemigo):
        daño = random.randint(14, 80) - (enemigo.defensa + enemigo.inteligencia)
        enemigo.vida -= daño
        print(f"{self.nombre} ha realizado un ataque fuerte causando {daño} puntos de daño a {enemigo.nombre}")

    def ataque_rapido(self, enemigo):
        daño = random.randint(14, 35) - (enemigo.defensa + enemigo.inteligencia)
        enemigo.vida -= daño
        print(f"{self.nombre} ha realizado un ataque rápido causando {daño} puntos de daño a {enemigo.nombre}")

class Mago(Personaje):
    def __init__(self, nombre, fuerza, inteligencia, defensa, vida, libro):
        super().__init__(nombre, fuerza, inteligencia, defensa, vida)
        self.libro = libro

    def atributos(self):
        super().atributos()
        print(f"·Libro: {self.libro}")

    def ataque_fuerte(self, enemigo):
        daño = random.randint(19, 80) - (enemigo.defensa + enemigo.inteligencia)
        enemigo.vida -= daño
        print(f"{self.nombre} ha realizado un ataque fuerte causando {daño} puntos de daño a {enemigo.nombre}")

    def ataque_rapido(self, enemigo):
        daño = random.randint(19, 35) - (enemigo.defensa + enemigo.inteligencia)
        enemigo.vida -= daño
        print(f"{self.nombre} ha realizado un ataque rápido causando {daño} puntos de daño a {enemigo.nombre}")
