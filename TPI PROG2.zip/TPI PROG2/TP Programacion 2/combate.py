import random

def combate(jugador_1, jugador_2):
    turno = random.choice([0, 1])  # Elegir al azar quién empieza
    while jugador_1.esta_vivo() & jugador_2.esta_vivo():
        print(f"\nTurno de {jugador_1.nombre}" if turno == 0 else f"\nTurno de {jugador_2.nombre}")
        if turno == 0:
            jugador_1.menu_ataque(jugador_2)
            turno = 1 if jugador_2.esta_vivo() else 0
        else:
            jugador_2.menu_ataque(jugador_1)
            turno = 0 if jugador_1.esta_vivo() else 1
    if jugador_1.esta_vivo():
        print(f"\nHa ganado {jugador_1.nombre}")
    elif jugador_2.esta_vivo():
        print(f"\nHa ganado {jugador_2.nombre}")
    else:
        print("\nEmpate")
