from datos import cargar_datos
from combate import combate

def main():
    personaje_1, personaje_2 = cargar_datos()

    print("\nAtributos iniciales de los personajes:")
    personaje_1.atributos()
    personaje_2.atributos()

    combate(personaje_1, personaje_2)

if __name__ == "__main__":
    main()
