from personaje import Guerrero, Mago

def crear_personaje(nombre, tipo):
    if tipo == 'Guerrero':
        return Guerrero(nombre, 20, 10, 4, 100, 4)
    elif tipo == 'Mago':
        return Mago(nombre, 5, 15, 4, 100, 3)
    else:
        raise ValueError("Tipo de personaje no válido")

def cargar_datos():
    print("Creación de personajes:")

    while True:
        nombre_1 = input("Ingrese el nombre del jugador 1: ")
        if nombre_1.strip():
            break
        else:
            print("El nombre no puede estar vacío. Inténtelo de nuevo.")

    while True:
        tipo_1 = input("Seleccione el tipo de personaje para jugador 1 (Guerrero/Mago): ")
        if tipo_1 in ['Guerrero', 'Mago']:
            break
        else:
            print("Tipo de personaje no válido. Inténtelo de nuevo.")

    jugador_1 = crear_personaje(nombre_1, tipo_1)

    while True:
        nombre_2 = input("Ingrese el nombre del jugador 2: ")
        if nombre_2.strip():
            break
        else:
            print("El nombre no puede estar vacío. Inténtelo de nuevo.")

    while True:
        tipo_2 = input("Seleccione el tipo de personaje para jugador 2 (Guerrero/Mago): ")
        if tipo_2 in ['Guerrero', 'Mago']:
            break
        else:
            print("Tipo de personaje no válido. Inténtelo de nuevo.")

    jugador_2 = crear_personaje(nombre_2, tipo_2)

    return jugador_1, jugador_2
